use eanprod;
SELECT * from regioncentercoordinateslist WHERE RegionName LIKE "%Paris, France%";
