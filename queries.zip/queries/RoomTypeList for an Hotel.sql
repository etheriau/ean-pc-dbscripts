use eanextras;
select * from airports;
